# Simple-Linear-Regression

A simple python program that implements Linear Regression on a sample dataset. The programuses sklearn.linear_model from the scikit-learn library to import the class LinearRegression. The object of the class is declared and is fitted with the X_Train and Y_Train data.

Y_Pred stores the predicted values of X_Test

A graph is plotted using the matplotlib.pyplot to visually represent the Linear Regression model.
